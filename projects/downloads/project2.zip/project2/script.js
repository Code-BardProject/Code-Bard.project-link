document.querySelector('.menu-btn').addEventListener('click', () => {
    const menu = document.querySelector('.menu');
    menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
    menu.classList.toggle('visible');
});

document.querySelector('.start-btn').addEventListener('click', () => {
    const hero = document.querySelector('.hero');
    const form = document.querySelector('.registration-form');
    hero.style.display = 'none';
    form.style.display = 'block';
    form.classList.add('visible');
});

document.querySelector('.close-btn').addEventListener('click', () => {
    const hero = document.querySelector('.hero');
    const form = document.querySelector('.registration-form');
    hero.style.display = 'block';
    form.style.display = 'none';
    form.classList.remove('visible');
});

document.querySelectorAll('input[name="bonusCard"]').forEach(radio => {
    radio.addEventListener('change', () => {
        const bonusCardInput = document.querySelector('#bonusCardInput');
        bonusCardInput.style.display = radio.value === 'yes' ? 'block' : 'none';
    });
});

document.querySelector('#registrationForm').addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Регистрация успешно отправлена!');
});