const cityTimeZones = {
    "Armenia": 4,
    "Dubai": 4,
    "London": 1,
    "New York": -4
};

let currentCity = "Armenia";
let userTimeZoneOffset = cityTimeZones[currentCity];

function getLocalTime() {
    const now = new Date();
    const userTime = new Date(now.getTime() + (userTimeZoneOffset * 3600 * 1000));
    
    const hours = userTime.getUTCHours();
    const minutes = userTime.getUTCMinutes();
    const seconds = userTime.getUTCSeconds();
    
    const day = userTime.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    
    return {
        date: day,
        time: `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`,
        seconds: `+0${userTimeZoneOffset}`
    };
}

function updateDateTime() {
    const dateElement = document.getElementById('date');
    const timeElement = document.getElementById('time');
    const secondsElement = document.getElementById('seconds');

    const timeData = getLocalTime();
    dateElement.textContent = timeData.date;
    timeElement.textContent = timeData.time;
    secondsElement.textContent = timeData.seconds;
}

setInterval(updateDateTime, 1000);
updateDateTime();

function updateLocation() {
    const cityInput = document.getElementById('city').value.trim();
    if (cityTimeZones[cityInput]) {
        currentCity = cityInput;
        userTimeZoneOffset = cityTimeZones[currentCity];
        updateDateTime();
        updateWeather();
    } else {
        alert("City not found. Please try: Armenia, Dubai, London, or New York.");
    }
}

const weatherData = {
    "Armenia": "Clear, +25°C, feels like +23°C, wind 1.5 m/s SE, humidity 34%, pressure 699 mmHg",
    "Dubai": "Sunny, +35°C, feels like +38°C, wind 3 m/s W, humidity 55%, pressure 752 mmHg",
    "London": "Cloudy, +15°C, feels like +14°C, wind 4 m/s SW, humidity 70%, pressure 1012 hPa",
    "New York": "Partly cloudy, +22°C, feels like +21°C, wind 2 m/s NE, humidity 60%, pressure 1015 hPa"
};

function updateWeather() {
    const weatherElement = document.getElementById('weather');
    weatherElement.textContent = weatherData[currentCity] || "Weather data not available";
}

updateWeather();

// Частицы на фоне
const canvas = document.getElementById('particles');
const ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const particles = [];
const particleCount = 50;

class Particle {
    constructor() {
        this.x = Math.random() * canvas.width;
        this.y = Math.random() * canvas.height;
        this.size = Math.random() * 5 + 1;
        this.speedX = Math.random() * 1 - 0.5;
        this.speedY = Math.random() * 1 - 0.5;
    }

    update() {
        this.x += this.speedX;
        this.y += this.speedY;

        if (this.x < 0 || this.x > canvas.width) this.speedX *= -1;
        if (this.y < 0 || this.y > canvas.height) this.speedY *= -1;
    }

    draw() {
        ctx.fillStyle = 'rgba(139, 90, 43, 0.5)';
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fill();
    }
}

for (let i = 0; i < particleCount; i++) {
    particles.push(new Particle());
}

function animateParticles() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (let i = 0; i < particles.length; i++) {
        particles[i].update();
        particles[i].draw();
    }
    requestAnimationFrame(animateParticles);
}

animateParticles();

// Основная логика
function checkCoffee() {
    const coffee = document.getElementById('coffee-status').value;
    const result = document.getElementById('result');
    const coffeeImage = document.getElementById('coffee-image');

    // Сбрасываем анимацию
    result.classList.remove('show');
    coffeeImage.classList.remove('show');

    // Обновляем изображение и текст
    setTimeout(() => {
        if (coffee === 'empty') {
            result.textContent = 'Fill';
            coffeeImage.textContent = '';
            coffeeImage.className = 'coffee-image empty';
        } else if (coffee === 'full') {
            result.textContent = 'Drink';
            coffeeImage.textContent = '';
            coffeeImage.className = 'coffee-image full';
        } else {
            result.textContent = 'So proceed... ☕';
            coffeeImage.textContent = '';
            coffeeImage.className = 'coffee-image other';
        }

        // Запускаем анимацию
        result.classList.add('show');
        coffeeImage.classList.add('show');
    }, 50);
}